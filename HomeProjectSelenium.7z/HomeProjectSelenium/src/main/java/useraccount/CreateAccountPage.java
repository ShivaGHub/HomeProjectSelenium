package useraccount;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;

import java.util.HashMap;

public class CreateAccountPage {
    private static final By ACCOUNT_TITLE = By.id("id_gender1");
    private static final By CUSTOMER_FIRST_NAME = By.id("customer_firstname");
    private static final By CUSTOMER_LAST_NAME = By.id("customer_lastname");
    private static final By CUSTOMER_EMAILADDRESS_INPUT = By.id("email");
    private static final By CUSTOMER_PASSWORD_INPUT = By.id("passwd");
    private static final By CUSTOMER_DOBDAYS_SELECT = By.id("days");
    private static final By CUSTOMER_DOBMONTHS_SELECT = By.id("months");
    private static final By CUSTOMER_DOBYEAR_SELECT = By.id("years");
    private static final By CUSTOMER_SUBSCRIBE_NEWLETTER = By.id("newsletter");
    private static final By CUSTOMER_SUBSCRIBE_SPECIALOFFERS = By.id("optin");
    private static final By ADDRESS_COMPANY = By.id("company");
    private static final By ADDRESS_INPUTONE = By.id("address1");
    private static final By ADDRESS_INPUTTWO = By.id("address2");
    private static final By ADDRESS_CITY = By.id("city");
    private static final By ADDRESS_STATE = By.id("id_state");
    private static final By ADDRESS_POSTCODE = By.id("postcode");
    private static final By CUSTOMER_ADDTLINFO_INPUT = By.id("other");
    private static final By CUSTOMER_WORKPHONE = By.id("phone");
    private static final By CUSTOMER_MOBILEPHONE = By.id("phone_mobile");
    private static final By ADDRESS_ALIAS_INPUT = By.id("alias");
    private static final By CREATEACCOUNT_SUBMIT = By.id("submitAccount");


    public void  createAccount(WebDriver driver, HashMap<String, String> dataMap) {

        Reporter.log("Create account Page: Driver selecting account title");
        WebDriverWait wait = new WebDriverWait(driver, 20);
        if(dataMap.get("title").equalsIgnoreCase("Mr")) {
            WebElement title = wait.until(ExpectedConditions.visibilityOfElementLocated(ACCOUNT_TITLE));
            title.click();
        }

        Reporter.log("Create account Page: Driver entering first name");
        driver.findElement(CUSTOMER_FIRST_NAME).sendKeys(dataMap.get("fName"));

        Reporter.log("Create account Page: Driver entering last name");
        driver.findElement(CUSTOMER_LAST_NAME).sendKeys(dataMap.get("lName"));

        Reporter.log("Create account Page: Driver entering pwd");
        driver.findElement(CUSTOMER_PASSWORD_INPUT).sendKeys(dataMap.get("pwd"));

        Reporter.log("Create account Page: Driver selecting day from the date field dropdown");
        WebElement dayElement = driver.findElement(CUSTOMER_DOBDAYS_SELECT);
        dayElement.click();
        WebElement daySelected = driver.findElement(By.cssSelector("option[value='"+Integer.parseInt(dataMap.get("day"))+"']"));
        daySelected.click();

        Reporter.log("Create account Page: Driver selecting month from the month field dropdown");
        WebElement monthElement = driver.findElement(CUSTOMER_DOBMONTHS_SELECT);
        monthElement.click();
        WebElement monthSelected = driver.findElement(By.cssSelector("#months option:nth-child("+Integer.parseInt(dataMap.get("month"))+")"));
        monthSelected.click();

        Reporter.log("Create account Page: Driver selecting year from the year field dropdown");
        WebElement yearElement = driver.findElement(CUSTOMER_DOBYEAR_SELECT);
        yearElement.click();
        WebElement yearToSelect = driver.findElement(By.cssSelector("option[value='"+Integer.parseInt(dataMap.get("year"))+"']"));
        yearToSelect.click();

        Reporter.log("Create account Page: Driver enabling checkbox to subscribe to newsletter");
        if(dataMap.get("newsLetter").equalsIgnoreCase("Y")) {
            driver.findElement(CUSTOMER_SUBSCRIBE_NEWLETTER).click();
        }
        Reporter.log("Create account Page: Driver enabling checkbox to subscribe to special offers");
        if(dataMap.get("Offers").equalsIgnoreCase("Y")) {
            driver.findElement(CUSTOMER_SUBSCRIBE_SPECIALOFFERS).click();
        }

        Reporter.log("Create account Page: Driver is entering company name");
        driver.findElement(ADDRESS_COMPANY).sendKeys(dataMap.get("company"));
        Reporter.log("Create account Page: Driver is entering address field one");
        driver.findElement(ADDRESS_INPUTONE).sendKeys(dataMap.get("addressOne"));
        Reporter.log("Create account Page: Driver is entering address field two");
        driver.findElement(ADDRESS_INPUTTWO).sendKeys(dataMap.get("addressTwo"));
        Reporter.log("Create account Page: Driver is entering city");
        driver.findElement(ADDRESS_CITY).sendKeys(dataMap.get("city"));

        Reporter.log("Create account Page: Driver is selecting state");
        WebElement stateSelector = driver.findElement(ADDRESS_STATE);
        stateSelector.click();

        WebElement state = driver.findElement(By.cssSelector("#id_state option:nth-child("+Integer.parseInt(dataMap.get("state"))+")"));
        state.click();

        Reporter.log("Create account Page: Driver is entering postcode");
        driver.findElement(ADDRESS_POSTCODE).sendKeys(dataMap.get("postCode"));

        Reporter.log("Create account Page: Driver is entering additoinal info");
        driver.findElement(CUSTOMER_ADDTLINFO_INPUT).sendKeys(dataMap.get("addInfo"));
        Reporter.log("Create account Page: Driver is entering work phone number");
        driver.findElement(CUSTOMER_WORKPHONE).sendKeys(dataMap.get("wPhone"));
        Reporter.log("Create account Page: Driver is entering mobile phone number");
        driver.findElement(CUSTOMER_MOBILEPHONE).sendKeys(dataMap.get("mPhone"));
        Reporter.log("Create account Page: Driver is entering alias name");
        driver.findElement(ADDRESS_ALIAS_INPUT).sendKeys(dataMap.get("alias"));

        Reporter.log("Create account Page: Submitting new account details");
        driver.findElement(CREATEACCOUNT_SUBMIT).click();
    }

}
