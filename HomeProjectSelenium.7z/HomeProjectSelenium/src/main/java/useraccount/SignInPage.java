package useraccount;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import java.util.Random;

public class SignInPage {
    private static final By EMAIL_CREATE = By.id("email_create");
    private static final By CREATE_ACCOUNT_BUTTON = By.id("SubmitCreate");

    public void clickCreateAccount(WebDriver driver){
        Reporter.log("Sign-in Page: inputting random email ID generated");
        driver.findElement(EMAIL_CREATE).sendKeys(generateRandomEmailID());
        Reporter.log("Sign-in Page: Clicking create account button");
        driver.findElement(CREATE_ACCOUNT_BUTTON).click();
    }

    public String generateRandomEmailID(){
        Random random = new Random();
        String randomString = "testalpha"+random.nextInt(100)+"@accountalphasense.com";
        System.out.println(randomString);
        return randomString;
    }

}
