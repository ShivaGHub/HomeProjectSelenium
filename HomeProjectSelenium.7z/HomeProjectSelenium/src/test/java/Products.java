import orders.OrderDetailsPage;
import org.testng.Assert;
import org.testng.Reporter;
import products.ProductDetailsPage;
import products.ProductSearchResultsPage;
import products.ShoppingCartPage;
import useraccount.AccountDetailsPage;

import java.util.ArrayList;

public class Products extends Home{
    AccountDetailsPage accountDetailsPage = null;
    ProductSearchResultsPage productSearchResultsPage = null;
    OrderDetailsPage orderDetailsPage = null;

    @org.testng.annotations.Test(priority = 0, description = "Verify that search using a keyword is returning records as expected")
    public void searchByKeyword(){
        try {
            Reporter.log("Search for products started with keyword Dresses");
            accountDetailsPage = new AccountDetailsPage();
            accountDetailsPage.searchProduct(driver, "Dress");
            Reporter.log("String verification of response count");
            productSearchResultsPage = new ProductSearchResultsPage();
            String prodsSearched = productSearchResultsPage.searchCount(driver);
            Assert.assertEquals(prodsSearched, "7 results have been found.");
            Reporter.log("Verification of response count - successful");
            Reporter.log("Verification of response products names started");
            ArrayList<String> dressNames = productSearchResultsPage.getDressNames(driver);
            System.out.println("size in Test" + dressNames.size());
            for (int j = 0; j < dressNames.size(); j++) {
                System.out.println(dressNames.get(j));
                String actualDressName = dressNames.get(j);
                Assert.assertTrue(actualDressName.contains("Dress") || actualDressName.contains("Blouse") || actualDressName.contains("Short Sleeve"));
            }
            Reporter.log("Verification of response products names is successful");
        }catch(Exception e){
                e.printStackTrace();
            }
    }

    @org.testng.annotations.Test(priority = 1, groups = {"Products.createAnOrder"},timeOut = 300000, description = "Verify that creating a new order is successful")
    public void createAnOrder(){
        try {
            Reporter.log("Creating an order started - added to cart");
            productSearchResultsPage.addToCart(driver);
            ProductDetailsPage productDetailsPage = new ProductDetailsPage();
            productDetailsPage.addToCartAndProceed(driver);
            Reporter.log("Creating an order - complete checkout and payment");
            ShoppingCartPage shoppingCartPage = new ShoppingCartPage();
            String actualMessage = shoppingCartPage.completeOrder(driver);
            Assert.assertEquals(actualMessage, "Your order on My Store is complete.");
            Reporter.log("Creating an order - is completed");
            shoppingCartPage.backToOrder(driver);
            orderDetailsPage = new OrderDetailsPage();
            int orderCount = orderDetailsPage.getOrderCount(driver);
            Assert.assertEquals("1", "1", "Order is created successfully");
            Reporter.log("Creating an order - verified successfully");
        }catch(Exception e){
            e.printStackTrace();;
        }
    }
}
