package products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class ProductDetailsPage {
    private static final By PRODDETAILS_ADDTOCART_BUTTON=By.name("Submit");
    private static final By PRODUCTDETAILS_CHECKOUT_BUTTON =By.cssSelector(".btn.btn-default.button.button-medium");


    public void addToCartAndProceed(WebDriver driver){
        Reporter.log(" Product Details Page: clicking on add to cart button");
        driver.findElement(PRODDETAILS_ADDTOCART_BUTTON).click();
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Reporter.log(" Product Details Page: Checking out selected dress");
        wait.until(ExpectedConditions.visibilityOfElementLocated(PRODUCTDETAILS_CHECKOUT_BUTTON)).click();
    }


}

