import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import useraccount.AccountDetailsPage;
import useraccount.CreateAccountPage;
import useraccount.HomePage;
import useraccount.SignInPage;

import java.util.HashMap;

public class CreateAccount extends Home{
    AccountDetailsPage accountDetailsPage = null;
    HashMap<String, String> accountDataMap = new HashMap<>(25);

    @org.testng.annotations.Test(priority = 0, dataProvider = "CreateAccountDataProvider", description = "Verify that new user account can be created successfully")
    public void createNewAccount(HashMap<String, String> dataMap){
        try {
            HomePage homePage = new HomePage();
            Reporter.log("Click on Sign-in on home page");
            homePage.clickSignIn(driver);
            Reporter.log("Sign in Clicked");
            SignInPage signInPage = new SignInPage();
            Reporter.log("New user account creation started");
            signInPage.clickCreateAccount(driver);
            CreateAccountPage createAccountPage = new CreateAccountPage();
            createAccountPage.createAccount(driver, dataMap);
            accountDetailsPage = new AccountDetailsPage();
            String actualMessage = accountDetailsPage.welcomeMessage(driver);
            Assert.assertEquals(actualMessage, "Welcome to your account. Here you can manage all of your personal information and orders.");
            Reporter.log("New user account is successfully created");
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @DataProvider(name = "CreateAccountDataProvider")
    public Object[][] CreateAccountDataProvider() {
        accountDataMap.put("title","Mr");
        accountDataMap.put("fName","TestfName");
        accountDataMap.put("lName","TestlName");
        accountDataMap.put("pwd","Welcome1");
        accountDataMap.put("day","21");
        accountDataMap.put("month","9");
        accountDataMap.put("year","2019");
        accountDataMap.put("newsLetter","Y");
        accountDataMap.put("Offers","Y");
        accountDataMap.put("company","Alphasense");
        accountDataMap.put("addressOne","Tammasaarenkatu 3");
        accountDataMap.put("addressTwo","Helsinki");
        accountDataMap.put("city","Helsinki");
        accountDataMap.put("state","6");
        accountDataMap.put("postCode","00000");
        accountDataMap.put("addInfo","None");
        accountDataMap.put("wPhone","0011100111");
        accountDataMap.put("mPhone","1111111111");
        accountDataMap.put("alias","Office");
        return new Object[][] {
                {accountDataMap}};
    }


}
