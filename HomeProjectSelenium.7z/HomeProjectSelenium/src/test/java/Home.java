import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriverLogLevel;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.logging.LoggingPreferences;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Reporter;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Listeners;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.Parameters;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

@Listeners(ImplementCustomListener.class)
public class Home {

    static WebDriver driver = null;

    @BeforeSuite
    public void setUp(){
        String url = System.getProperty("propertyName");
        String browser = System.getProperty("browser");
        String driverPath = System.getProperty("driverPath");
        System.out.println("browser" + browser);
        if(browser.equalsIgnoreCase("firefox")){
            System.setProperty("webdriver.gecko.driver",driverPath);
            driver = new FirefoxDriver();
        }else if(browser.equalsIgnoreCase("chrome")){
             System.setProperty("webdriver.chrome.driver",driverPath);
             driver = new ChromeDriver();
      }
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        driver.get(url);
        Reporter.log("Driver instantiation is successful and URL is launched.");
    }

    @AfterSuite
    public void tearDown(){
        driver.quit();
    }

    public String getTargetLocation(){
        String targetLocation = System.getProperty("targetLocation");
        return targetLocation;
    }

}

