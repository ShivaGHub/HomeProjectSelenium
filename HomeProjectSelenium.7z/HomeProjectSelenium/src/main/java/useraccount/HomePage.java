package useraccount;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

public class HomePage {
    private static final By LOGIN = By.className("login");

    public void clickSignIn(WebDriver driver){
        Reporter.log("Welcome Page: Driver is clicking on Sign-in link");
        driver.findElement(LOGIN).click();
    }
}
