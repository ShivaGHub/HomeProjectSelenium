import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.logging.LogEntries;
import org.openqa.selenium.logging.LogEntry;
import org.openqa.selenium.logging.LogType;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.Reporter;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Welcome extends Home{
    @org.testng.annotations.Test(priority = 0, dependsOnGroups={"Products.createAnOrder", "Orders.downloadAndVerify"},description = "Verify if the Home page title is AlphaSense. Negative test case")
    public void verifyHomePageTitle(){
        try {
            Reporter.log("Verify if the title of the Welcome page is Alphasense");
            String pageTitle = driver.getTitle();
            Assert.assertEquals(pageTitle, "AlphaSense");

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    public void screenShotIfFailed() throws IOException {
        Reporter.log("In screenshot Method");
        File sourceFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        Reporter.log("In screenshot Method Two");
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        String screenShotName = "Screenshot"+(simpleDateFormat.format(timestamp)).replace(".","")+".png";
        String targetLocation = getTargetLocation();
        Reporter.log("Screenshot is at location"+targetLocation+" "+screenShotName);
        try {
            FileUtils.copyFile(sourceFile, new File(targetLocation + screenShotName));
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    public void browserLogsOnFailure() {
//        LogEntries logs = driver.manage().logs().get(LogType.BROWSER);
//        for(LogEntry log: logs ){
//            System.out.println("Timestamp:"+ " "+new Date(log.getTimestamp()) + "LogLevel"+ log.getLevel() + "Message:"+ " "+ log.getMessage());
//
          LogEntries logs = driver.manage().logs().get("browser");
          System.out.println(logs.toString());
    }
}
