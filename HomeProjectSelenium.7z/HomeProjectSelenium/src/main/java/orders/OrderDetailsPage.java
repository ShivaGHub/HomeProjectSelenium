package orders;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class OrderDetailsPage{

    private static final By ORDERS_TABLE =By.xpath("//*[@id='order-list']/tbody/tr");
    private static final By ORDERS_TABLE_LINKBUTTON =By.className("link-button");

    public int getOrderCount(WebDriver driver){
        return driver.findElements(ORDERS_TABLE).size();
    }

    public void downloadInvoicePDF(WebDriver driver){

        driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
        WebDriverWait webDriverWait = new WebDriverWait(driver,  30);
        Reporter.log("Downloading of order invoice: clicking pdf download link button ");
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(ORDERS_TABLE_LINKBUTTON)).click();
    }
}
