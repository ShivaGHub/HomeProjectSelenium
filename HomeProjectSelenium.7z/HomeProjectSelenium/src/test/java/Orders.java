import orders.OrderDetailsPage;
import org.testng.Assert;
import org.testng.Reporter;


import java.awt.*;
import java.awt.event.KeyEvent;
import java.io.File;

public class Orders extends Home{

    OrderDetailsPage orderDetailsPage = null;

    @org.testng.annotations.Test(priority = 0, dependsOnGroups={"Products.createAnOrder"}, groups = {"Orders.downloadAndVerify"}, timeOut = 300000, description = "Verify product order invoice can be downloaded and verify that download is successful")
    public void downloadAndVerify() throws AWTException, InterruptedException{
        try {
            invoiceDownload();
            verifyFileDownload();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void invoiceDownload() throws AWTException, InterruptedException{
        Thread.sleep(5000);
        Reporter.log("Order invoice download is starting", 1);
        orderDetailsPage = new OrderDetailsPage();
        orderDetailsPage.downloadInvoicePDF(driver);
        Robot robot = new Robot();
        Thread.sleep(5000);
        Reporter.log("Clicking on Ok of the Opening PDF dialog");
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(3000);
    }

    public void verifyFileDownload() throws InterruptedException, AWTException{
        String downLoadInvoiceLocation = System.getProperty("invoiceDownladLocation");
        File directoryFile = new File(downLoadInvoiceLocation);
        File[] listOfFiles = directoryFile.listFiles();
        String downloadOneName = getLastFileModified(listOfFiles);
        Reporter.log("Downloading again to verify if the file names are same such that verification can be done",2);
        invoiceDownload(); //Downloading second time to compare with previous file name and verify invoice download
        listOfFiles = directoryFile.listFiles();
        String downloadTwoName = getLastFileModified(listOfFiles);
        Assert.assertEquals(downloadTwoName.substring(0,7), downloadOneName.substring(0,7),
                "Files names and extensions are matching, hence, file is downloaded successfully");
        Reporter.log("Download of order invoice is successful");
    }

    public String getLastFileModified(File[] listOfFiles){
        Reporter.log("Verifying if the last modified file is pdf and returning last modified file");
        String lastDownloadedFileName = null;
        File lastFileDownloaded = listOfFiles[0];
        for(int i=1;i<listOfFiles.length;i++){
            if(lastFileDownloaded.lastModified()<listOfFiles[i].lastModified()){
                lastFileDownloaded=listOfFiles[i];
            }
        }
        if (lastFileDownloaded.getName().contains("pdf")) {
            lastDownloadedFileName = lastFileDownloaded.getName();
            System.out.println(lastDownloadedFileName);
        }
        return  lastDownloadedFileName;
    }
}
