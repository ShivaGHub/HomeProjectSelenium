package products;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import java.util.concurrent.TimeUnit;

public class ShoppingCartPage {
    private static final By CART_PROCEED=By.cssSelector(".button.btn.btn-default.standard-checkout.button-medium");
    private static final By CART_ADDRESSE_BUTTON=By.name("processAddress");
    private static final By CART_TOSERVICE_SELECT=By.name("cgv");
    private static final By CART_SHIPPINGADDR_BUTTON=By.name("processCarrier");
    private static final By CART_PROCEED_PAYMODE=By.className("cheque");
    private static final By CART_CONFIRMORDER_BUTTON=By.xpath("/html/body/div/div[2]/div/div[3]/div/form/p/button");
    private static final By CART_CONFIRMMESSAGE_ALERT=By.cssSelector(".alert.alert-success");
    private static final By CART_BACKTOORDER_BUTTON=By.cssSelector(".button-exclusive.btn.btn-default");


    public String completeOrder(WebDriver driver){
        Reporter.log("Order: Clicking on proceed further");
        driver.findElement(CART_PROCEED).click();
        WebDriverWait wait = new WebDriverWait(driver, 20);
        Reporter.log("Order: Clicking on address confirmation button");
        wait.until(ExpectedConditions.visibilityOfElementLocated(CART_ADDRESSE_BUTTON)).click();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        Reporter.log("Order: Selecting checkbox to agree to T&C");
        WebElement agreeCheckBox = driver.findElement(CART_TOSERVICE_SELECT);
        Actions actions = new Actions(driver);
        actions.moveToElement(agreeCheckBox);
        agreeCheckBox.click();
        Reporter.log("Order: Clicking confirming shipping address page button");
        driver.findElement(CART_SHIPPINGADDR_BUTTON).click();
        Reporter.log("Order: Selecting payment mode by clicking on button");
        wait.until(ExpectedConditions.visibilityOfElementLocated(CART_PROCEED_PAYMODE)).click();
        Reporter.log("Order: Clicking on confirmation button");
        WebElement confirmButton = driver.findElement(CART_CONFIRMORDER_BUTTON);
        JavascriptExecutor jexec = (JavascriptExecutor) driver;
        jexec.executeScript("arguments[0].click();",confirmButton);
        System.out.println("Clicked on confirmorder button");
        Reporter.log("Order confirmation: Fetching and returning order confirmation message");
        return wait.until(ExpectedConditions.visibilityOfElementLocated(CART_CONFIRMMESSAGE_ALERT)).getText();
    }

    public void backToOrder(WebDriver driver){
        Reporter.log(" Order confirmation Page: Clicking on back to order link button");
        driver.findElement(CART_BACKTOORDER_BUTTON).click();

    }



}
