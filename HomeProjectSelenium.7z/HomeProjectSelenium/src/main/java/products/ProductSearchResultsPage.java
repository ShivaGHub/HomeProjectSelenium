package products;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import java.util.ArrayList;
import java.util.List;

public class ProductSearchResultsPage {
    private static final By SEARCH_RESULTS_COUNT = By.className("heading-counter");
    private static final By SEARCH_PRODUCTLIST_UL=By.xpath("//*[@id='center_column']/ul/li");
    private static final By PRODUCTITEM_HOVER=By.cssSelector(".replace-2x.img-responsive");


    public ArrayList<String> getDressNames(WebDriver driver){
        Reporter.log(" Product List: iterating through all the products displayed for verification: getting each dress name:");
        List<WebElement> list= driver.findElements(SEARCH_PRODUCTLIST_UL);
        System.out.println("size of the list"+list.size());
        ArrayList<String> dressesList = new ArrayList<String>();
        for(int i=1;i<list.size()+1;i++){
            System.out.println(driver.findElement(By.xpath("//*[@id='center_column']/ul/li["+i+"]/div/div[2]/h5/a")).getText());
            dressesList.add(driver.findElement(By.xpath("//*[@id='center_column']/ul/li["+i+"]/div/div[2]/h5/a")).getText());
        }
        return dressesList;

    }

    public String searchCount(WebDriver driver){
        Reporter.log(" Product List: Fetching the product count from product list page");
        return driver.findElement(SEARCH_RESULTS_COUNT).getText();
    }

    public void addToCart(WebDriver driver){
        Reporter.log(" Product List: Hovering on 2nd product to select for order");
        driver.findElement(PRODUCTITEM_HOVER).click();
    }
}
