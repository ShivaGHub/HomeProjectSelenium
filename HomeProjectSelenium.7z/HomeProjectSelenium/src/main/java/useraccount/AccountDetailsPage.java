package useraccount;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

public class AccountDetailsPage {
    private static final By MYACCOUNT_WELCOME = By.className("info-account");
    private static final By ACCOUNT_SEARCH_INPUT= By.id("search_query_top");
    private static final By ACCOUNT_SEARCH_QUERY= By.name("submit_search");

    public String welcomeMessage(WebDriver driver){
        Reporter.log("Driver is locating welcome page field");
        WebDriverWait wait = new WebDriverWait(driver, 20);
        return wait.until(ExpectedConditions.visibilityOfElementLocated(MYACCOUNT_WELCOME)).getText();
    }

    public void searchProduct(WebDriver driver, String productToSearch){
        Reporter.log("Driver is clearing input search field");
        driver.findElement(ACCOUNT_SEARCH_INPUT).clear();
        Reporter.log("Driver is inputting search field ");
        driver.findElement(ACCOUNT_SEARCH_INPUT).sendKeys(productToSearch);
        Reporter.log("Driver is identifying query button and clicking");
        driver.findElement(ACCOUNT_SEARCH_QUERY).click();
    }

   }
